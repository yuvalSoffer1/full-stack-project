export type CreateClassPayload = {
  className: string;
  groupId: number;
};

export type AddStudentsToClassPayload = {
  studentsIds: string[];
};
