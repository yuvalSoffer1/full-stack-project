export interface ILoginResponse {
  firstName: string;
  lastName: string;
}
