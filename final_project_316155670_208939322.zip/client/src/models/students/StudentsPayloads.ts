export type CreateStudentPayload = {
  studentId: string;
  firstName: string;
  lastName: string;
  prefixPhoneNumber: string;
  phoneNumber: string;
};
