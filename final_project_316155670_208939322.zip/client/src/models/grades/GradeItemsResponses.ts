export interface IGradeItemResponse {
  gradeItemId: number;
  name: string;
  weight: number;
}
